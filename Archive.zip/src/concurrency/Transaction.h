//
// Created by y on 2019-06-11.
//

#ifndef MINISQL_TRANSACTION_H
#define MINISQL_TRANSACTION_H


class Transaction {
    //not implemented

};


#endif //MINISQL_TRANSACTION_H
