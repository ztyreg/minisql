//
// Created by y on 2019-06-11.
//

#ifndef MINISQL_TUPLE_H
#define MINISQL_TUPLE_H


class Tuple {

};


#endif //MINISQL_TUPLE_H
