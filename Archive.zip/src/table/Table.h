//
// Created by y on 2019-06-15.
//

#ifndef MINISQL_TABLE_H
#define MINISQL_TABLE_H


class Table {

};


#endif //MINISQL_TABLE_H
