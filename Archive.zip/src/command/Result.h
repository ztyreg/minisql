//
// Created by y on 2019-05-25.
//

#ifndef PROJECT_RESULT_H
#define PROJECT_RESULT_H


class Result
{

};


#endif //PROJECT_RESULT_H
