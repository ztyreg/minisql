//
// Created by y on 2019-06-15.
//

#ifndef MINISQL_INDEXPAGE_H
#define MINISQL_INDEXPAGE_H


class IndexPage {

};


#endif //MINISQL_INDEXPAGE_H
