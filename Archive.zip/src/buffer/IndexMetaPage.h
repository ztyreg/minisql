//
// Created by y on 2019-06-15.
//

#ifndef MINISQL_INDEXMETAPAGE_H
#define MINISQL_INDEXMETAPAGE_H


class IndexMetaPage {

};


#endif //MINISQL_INDEXMETAPAGE_H
