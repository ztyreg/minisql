//
// Created by y on 2019-06-11.
//

#include <cstdio>

#include "../../src/buffer/BufferPoolManager.h"
#include "gtest/gtest.h"

TEST(BufferPoolManagerTest, SampleTest)
{

}
